<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Dynamically Generate HTML Elements With JavaScript</title>
</head>
<link rel = "stylesheet" type="text/css" href ="style.css">
<body>
  <!-- Generate this for each node
  <div>
    <img src="" alt="">
    <h3></h3>
    <p><a href=""></a></p>
    <button></button>
  </div> -->
  <div class="wrapper">
    <h1>Welcome to Friends Page!!</h1>
  </div>
  <div class="button">

  </div>

  <script>
    const socials = [
      {
        name: 'Mai Sarabia',
        city: 'Berlin',
        country: 'Germany',
        avatar: '../assets/avatar-1.png'
      },
      {
        name: 'Elsa Johansson',
        city: 'Oslo',
        country: 'Norway',
        avatar: '../assets/avatar-2.png'
      },
      {
        name: 'Shonda Green',
        city: 'San Francisco',
        country: 'USA',
        avatar: '../assets/avatar-3.png'
      },
      {
        name: 'Daniel Nagy',
        city: 'Budapest',
        country: 'Hungary',
        avatar: '../assets/avatar-4.png'
      }
    ];

    //query selector for one node
    const wrapper = document.querySelector('.wrapper');

    socials.forEach(user => {
      let socialWrapper  = document.createElement('div');
      //socialWrapper.style = 'border:2px solid red';


      let avatar = document.createElement('img');
      avatar.src = user.avatar;
      avatar.name = user.name;
      //add items to DOM
      socialWrapper.appendChild(avatar);
      wrapper.appendChild(socialWrapper);

      let name = document.createElement('h3');
      name.innerHTML = user.name;
      socialWrapper.appendChild(name);

      let location = document.createElement('p');
      location.innerHTML = user.city +", " + user.country;
      socialWrapper.appendChild(location);

      let AddFriendButton = document.createElement('button');
      AddFriendButton.innerHTML = 'Add Friend';
      socialWrapper.appendChild(AddFriendButton);
      var button = document.querySelector('button');
      button.addEventListener('click',myFunction);

      function myFunction(){
        //alert("new friend added!");
      }



      //DISPLAY CITY AND COUNTRY USING PREPEND AND INNER NODE
      // let loc = document.createElement('p');
      // loc.innerText = user.country;
      // let city = document.createElement('a');
      // city.src = '#';
      // city.appendChild(document.createElement(`{user.city}, `));
      // loc.prepend(city);
      // socialWrapper.appendChild(loc);


      //add child to DOM



    });

  </script>

</body>

</html>
